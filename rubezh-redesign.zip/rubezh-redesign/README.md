# РУБЕЖ — концепт редизайна сайта

Макеты: главная (`index.html`) и посадочная «Бетон» (`beton.html`).

## Публикация на GitHub Pages
1. Создайте репозиторий и загрузите содержимое папки (index.html, beton.html, assets/).
2. Settings → Pages → Source: *Deploy from a branch*, ветка `main`, папка `/ (root)`.
3. Через 1–2 минуты сайт будет по адресу `https://<логин>.github.io/<репозиторий>/`.
